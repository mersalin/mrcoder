package com.mersalin.falcon;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import java.util.LinkedHashMap;

/**
 * Created by mastho on 8/7/2017.
 */
public class LambdaHandler implements RequestHandler<LinkedHashMap, String> {
    @Override
    public String handleRequest(LinkedHashMap linkedHashMap, Context context) {
        return null;
    }
}
