package com.mersalin.falcon.feed;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mastho on 8/7/2017.
 */
public class Feed {
    private String title;
    private String description;
    private String link;
    private String imageUrl;

    final List<FeedEntry> entries = new ArrayList<>();

    public Feed(String title, String description, String link, String imageUrl) {
        this.title = title;
        this.description = description;
        this.link = link;
        this.imageUrl = imageUrl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public List<FeedEntry> getEntries() {
        return entries;
    }

    @Override
    public String toString() {
        return "Feed{" +
                "title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", link='" + link + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", entries=" + entries +
                '}';
    }
}
