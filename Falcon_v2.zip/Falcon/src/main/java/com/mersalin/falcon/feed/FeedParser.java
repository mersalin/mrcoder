package com.mersalin.falcon.feed;

/**
 * Created by mastho on 8/7/2017.
 */
public interface FeedParser {
    Feed readFeed();
}
