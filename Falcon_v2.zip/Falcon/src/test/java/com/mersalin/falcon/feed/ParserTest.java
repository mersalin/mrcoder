package com.mersalin.falcon.feed;

import com.mersalin.falcon.feed.bbc.BBCParserTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * Created by mastho on 8/7/2017.
 */

@RunWith(Suite.class)

@Suite.SuiteClasses({
    BBCParserTest.class
})

public class ParserTest {

}

