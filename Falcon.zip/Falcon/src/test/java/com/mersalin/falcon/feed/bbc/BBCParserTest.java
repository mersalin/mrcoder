package com.mersalin.falcon.feed.bbc;

import com.mersalin.falcon.feed.Feed;
import com.mersalin.falcon.feed.FeedEntry;
import com.mersalin.falcon.feed.FeedParser;
import org.junit.Assert;
import org.junit.Test;

/**
 * Created by mastho on 8/7/2017.
 */
public class BBCParserTest {
    @Test
    public void testParser() {
        FeedParser parser = new BBCFeedParser(
                "http://feeds.bbci.co.uk/tamil/rss.xml");
        Feed feed = parser.readFeed();
        System.out.println(feed);
        for (FeedEntry entry : feed.getEntries()) {
            System.out.println(entry);

        }
        Assert.assertTrue(feed.getTitle().contains("BBC Tamil"));
    }
}
